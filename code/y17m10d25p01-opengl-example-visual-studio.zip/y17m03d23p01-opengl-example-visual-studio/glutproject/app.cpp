#include "glut_app.h"
// Your initialization code goes here.
void initialize_app()
{
}
